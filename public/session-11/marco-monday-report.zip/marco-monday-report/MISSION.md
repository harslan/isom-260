# Marco's Monday Report

Marco runs North End Noodle Co. Every Monday he wants to know how last week went.
This folder has one file of real-looking data: sales.csv (7 days, 3 dishes).

## Round 1: copy this into OpenCode

Read sales.csv. Build Marco a one-page report as report.html: the total for the week,
money by dish, money by day, one simple bar chart, and three things he should do next week.
Keep it clean and easy to read. When you're done, tell me how to open it.

## Round 2: change one thing

Add ONE sentence to AGENTS.md (a file of rules this agent reads every time).
Save it. Start a new session, so the agent reads your new sentence.
Then ask: "Rebuild report.html from sales.csv."
