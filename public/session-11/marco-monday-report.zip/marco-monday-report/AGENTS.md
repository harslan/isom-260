# Rules for the agent working in this folder

<!-- Round 2: write ONE sentence below this line, then ask the agent to rebuild report.html. -->
